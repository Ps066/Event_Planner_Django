<?php
$host = "localhost";
$username = "root";
$pass = "";
$dbName="recyclo";
$port = 3308;


$conn = mysqli_connect($host,$username,$pass,$dbName,$port);

// if($conn){
//     echo "Success";
// }else{
//     echo "failed";
// }




?>